const params = new URLSearchParams(window.location.search);
const filmId = params.get('id');

const statusEl = document.getElementById('film-status');
const contentEl = document.getElementById('film-content');

if (!filmId) {
  statusEl.textContent = 'Фильм не указан.';
} else {
  loadFilm(filmId);
}

async function loadFilm(id) {
  try {
    const res = await fetch(`/api/film/${id}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Ошибка');

    renderFilm(data.movie);
    renderMirrors(data.mirrors);
    statusEl.hidden = true;
    contentEl.hidden = false;
  } catch (err) {
    statusEl.textContent = err.message;
  }
}

function renderFilm(movie) {
  document.title = `${movie.name} — Кино Olxi`;
  document.getElementById('film-title').textContent = movie.name;
  document.getElementById('film-meta').textContent =
    `${movie.year} · ${movie.type} · Рейтинг Кинопоиска: ${movie.rating}`;
  document.getElementById('film-description').textContent = movie.description;

  const img = document.getElementById('film-poster-img');
  if (movie.poster) {
    img.src = movie.poster;
    img.alt = movie.name;
  } else {
    img.style.display = 'none';
  }
}

function renderMirrors(mirrors) {
  const container = document.getElementById('watch-buttons');
  if (!mirrors.length) {
    container.textContent = 'Ссылки на просмотр пока не настроены.';
    return;
  }
  container.innerHTML = mirrors.map((m) =>
    `<a class="watch-btn" href="${m.url}" target="_blank" rel="noopener noreferrer">${m.name}</a>`
  ).join('');
}