const form = document.getElementById('search-form');
const input = document.getElementById('search-input');
const statusEl = document.getElementById('status');
const resultsEl = document.getElementById('results');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const query = input.value.trim();
  if (!query) return;

  statusEl.textContent = 'Поиск…';
  resultsEl.innerHTML = '';

  try {
    const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Ошибка');

    if (!data.results.length) {
      statusEl.textContent = 'Ничего не найдено.';
      return;
    }
    statusEl.textContent = `Найдено: ${data.results.length}`;
    renderResults(data.results);
  } catch (err) {
    statusEl.textContent = err.message;
  }
});

function renderResults(results) {
  resultsEl.innerHTML = results.map((m) => `
    <a class="result-row" href="/film.html?id=${m.id}">
      <div class="poster">
        ${m.poster
          ? `<img src="${m.poster}" alt="${escapeHtml(m.name)}" loading="lazy" />`
          : '<div class="poster-placeholder">🎬</div>'}
      </div>
      <div class="info">
        <div class="title">${escapeHtml(m.name)}</div>
        <div class="meta">${m.year} · ${m.type} · Рейтинг: ${m.rating}</div>
      </div>
      <div class="arrow">→</div>
    </a>
  `).join('');
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"]/g, (s) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;',
  }[s]));
}