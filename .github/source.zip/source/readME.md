# 🎬 Кино Olxi — исходники

**Бесплатный Open-Source проект.** Предоставляется «как есть», без гарантий.

## Что внутри
- `server.js` — Express-бэкенд (продакшн)
- `public/` — фронтенд для Express (реальные данные с kinopoisk.dev)
- `www/` — автономный APK-интерфейс (моки + все приколы, работает без сервера)
- `config/mirrors.js` — конфиг зеркал (легко расширяется)
- `services/kinopoisk.js` — клиент kinopoisk.dev с кэшем
- `token.env` — файл с токеном (заполните локально, НЕ коммитьте)
- `capacitor.config.ts` — конфиг Capacitor для APK

## Локальный запуск сервера
```bash
# 1. Вставьте токен
nano token.env
# KINOPOISK_API_TOKEN=ваш_токен_от_@kinopoiskdev_bot

# 2. Установите зависимости
npm install

# 3. Запустите
npm start
# → http://localhost:3000
- Локальный запуск (Интерфейс)