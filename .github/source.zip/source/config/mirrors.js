// Расширяемый конфиг зеркал.
// Добавить новое зеркало = добавить один объект в массив MIRRORS.
// Страницу фильма и остальную логику менять не нужно.

const MIRRORS = [
  {
    name: 'Убежище',
    // Правило: заменить «kinopoisk» на «sspoisk» в URL.
    // https://www.kinopoisk.ru/film/123/ → https://www.sspoisk.ru/film/123/
    transform: (url) => url.replace('kinopoisk', 'sspoisk'),
  },
  {
    name: 'Зеркало',
    // Правило: заменить «.ru» на «.me».
    transform: (url) => url.replace('.ru', '.me'),
  },
  {
    name: 'CX',
    // Правило: заменить «.ru» на «.cx».
    transform: (url) => url.replace('.ru', '.cx'),
  },
];

/**
 * Генерирует кнопки-ссылки на зеркала из URL Кинопоиска.
 * @param {string} kinopoiskUrl — https://www.kinopoisk.ru/film/123/
 * @returns {{name: string, url: string}[]}
 */
function generateMirrors(kinopoiskUrl) {
  if (!kinopoiskUrl) return [];
  return MIRRORS.map((m) => ({ name: m.name, url: m.transform(kinopoiskUrl) }));
}

module.exports = { MIRRORS, generateMirrors };