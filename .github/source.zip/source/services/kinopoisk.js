const axios = require('axios');
const NodeCache = require('node-cache');

const API_BASE = 'https://api.kinopoisk.dev/v1.4';
const API_TOKEN = process.env.KINOPOISK_API_TOKEN;

if (!API_TOKEN || API_TOKEN.includes('ВСТАВЬТЕ')) {
  console.warn('⚠️  KINOPOISK_API_TOKEN не задан в token.env — поиск не работает.');
}

// TTL 1 час — экономит лимит бесплатного тарифа (~200 запросов/день)
const cache = new NodeCache({ stdTTL: 3600 });

const client = axios.create({
  baseURL: API_BASE,
  headers: { 'X-API-KEY': API_TOKEN },
  timeout: 10000,
});

async function searchMovies(query) {
  const cacheKey = `search:${query.toLowerCase()}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const { data } = await client.get('/movie/search', {
    params: { query, page: 1, limit: 20 },
  });

  const results = (data.docs || []).map((m) => ({
    id: m.id,
    name: m.name || m.alternativeName || 'Без названия',
    year: m.year || '—',
    type: m.type === 'tv-series' ? 'Сериал' : 'Фильм',
    rating: m.rating?.kp ?? '—',
    poster: m.poster?.url ?? null,
    kinopoiskUrl: `https://www.kinopoisk.ru/film/${m.id}/`,
  }));

  cache.set(cacheKey, results);
  return results;
}

async function getMovieById(id) {
  const cacheKey = `movie:${id}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const { data } = await client.get(`/movie/${id}`);

  const movie = {
    id: data.id,
    name: data.name || data.alternativeName || 'Без названия',
    year: data.year || '—',
    type: data.type === 'tv-series' ? 'Сериал' : 'Фильм',
    rating: data.rating?.kp ?? '—',
    description: data.description || 'Описание отсутствует.',
    poster: data.poster?.url ?? null,
    kinopoiskUrl: `https://www.kinopoisk.ru/film/${data.id}/`,
  };

  cache.set(cacheKey, movie);
  return movie;
}

module.exports = { searchMovies, getMovieById };