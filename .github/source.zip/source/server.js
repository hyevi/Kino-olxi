// ВАЖНО: файл с токеном называется token.env (не .env)
require('dotenv').config({ path: 'token.env' });

const express = require('express');
const path = require('path');
const { searchMovies, getMovieById } = require('./services/kinopoisk');
const { generateMirrors } = require('./config/mirrors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

// --- API ---
app.get('/api/search', async (req, res) => {
  const query = (req.query.q || '').trim();
  if (!query) return res.status(400).json({ error: 'Введите название' });

  try {
    const results = await searchMovies(query);
    res.json({ results });
  } catch (err) {
    console.error('Ошибка поиска:', err.message);
    res.status(500).json({ error: 'Не удалось выполнить поиск. Попробуйте позже.' });
  }
});

app.get('/api/film/:id', async (req, res) => {
  try {
    const movie = await getMovieById(req.params.id);
    const mirrors = generateMirrors(movie.kinopoiskUrl);
    res.json({ movie, mirrors });
  } catch (err) {
    console.error('Ошибка получения фильма:', err.message);
    res.status(500).json({ error: 'Не удалось загрузить фильм.' });
  }
});

// Внутренняя карточка (.html на нашем домене, не внешняя ссылка)
app.get('/film.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'film.html'));
});

app.listen(PORT, () => {
  console.log(`🎬 Кино Olxi → http://localhost:${PORT}`);
});