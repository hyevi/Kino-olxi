import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.olxi.kino',
  appName: 'Кино Olxi',
  webDir: 'www',
  // никакого server.url — только локальный www/
};

export default config;